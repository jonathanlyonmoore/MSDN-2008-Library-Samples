//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ActiveDoc.rc
//
#define IDI_ICON1                       1
#define IDS_PROJNAME                    100
#define IDR_ActiveDoc                   101
#define IDR_MAINMENU                    203
#define IDD_ABOUT                       204
#define IDB_TOOLBAR                     207
#define IDR_TOOLBAR1                    208
#define ID_BLACK                        32770
#define ID_RED                          32771
#define ID_GREEN                        32772
#define ID_BLUE                         32773
#define ID_HELP_ABOUT                   32774
#define ID_BUTTON32779                  32775
#define ID_BUTTON32780                  32776
#define ID_BUTTON32782                  32777
#define ID_BUTTON32783                  32778
#define ID_BUTTON32784                  32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        211
#define _APS_NEXT_COMMAND_VALUE         32788
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
