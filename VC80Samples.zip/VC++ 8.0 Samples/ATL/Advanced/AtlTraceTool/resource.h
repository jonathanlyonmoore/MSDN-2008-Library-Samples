//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by tracetool.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TRACETOOL_DIALOG            102
#define IDS_CLOSEWITHOUTAPPLY           102
#define IDR_MAINFRAME                   128
#define VER_LANGID_HEX                  0409
#define IDC_BUTTON1                     1002
#define ID_REFRESH                      1002
#define ID_PROCESS_SLIDER_LEVEL         1003
#define ID_MODULE_SLIDER_LEVEL          1004
#define ID_CATEGORY_SLIDER_LEVEL        1005
#define ID_PROCESS_STATIC1              1006
#define ID_PROCESS_STATIC2              1007
#define ID_PROCESS_STATIC3              1008
#define ID_APPLY                        1009
#define ID_MODULE_STATIC1               1010
#define ID_MODULE_STATIC2               1011
#define ID_MODULE_STATIC3               1012
#define ID_CATEGORY_STATIC1             1013
#define ID_CATEGORY_STATIC2             1014
#define ID_CATEGORY_STATIC3             1015
#define ID_CLOSE                        1018
#define ID_TRACE_TREE                   1019
#define ID_SAVE                         1028
#define ID_LOAD                         1029
#define ID_CATEGORY_EDIT_LEVEL          1030
#define ID_CATEGORY_SPIN_LEVEL          1031
#define ID_PROCESS_EDIT_LEVEL           1032
#define ID_MODULE_EDIT_LEVEL            1033
#define VER_LANGID                      0x0409
#define ID_PROCESS_CHECKBOX_ENABLED     1036
#define ID_PROCESS_SPIN_LEVEL           1038
#define ID_MODULE_SPIN_LEVEL            1039
#define ID_PROCESS_GROUPBOX             1040
#define ID_PROCESS_STATIC_TRACELEVEL    1041
#define ID_CATEGORY_GROUPBOX            1042
#define ID_CATEGORY_STATIC_TRACELEVEL   1043
#define ID_MODULE_STATIC_TRACELEVEL     1044
#define ID_MODULE_GROUPBOX              1045
#define ID_PROCESS_CHECKBOX_FILENAMEANDLINENO 1050
#define ID_MODULE_RADIO_INHERIT         1051
#define ID_MODULE_RADIO_ENABLED         1052
#define ID_MODULE_RADIO_DISABLED        1053
#define ID_PROCESS_CHECKBOX_FUNCANDCATNAMES 1054
#define ID_CATEGORY_RADIO_INHERIT       1057
#define ID_CATEGORY_RADIO_ENABLED       1058
#define ID_CATEGORY_RADIO_DISABLED      1059
#define VER_CODEPAGE                    0x04b0
#define IDS_INVALIDFILENAME		103
// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
