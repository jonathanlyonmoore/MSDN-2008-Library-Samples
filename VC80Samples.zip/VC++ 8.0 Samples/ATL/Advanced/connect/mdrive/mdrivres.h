//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MDrive.rc
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Classes Reference and related electronic
// documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft C++ Libraries products.

#define IDB_START                       3
#define IDB_STOP                        4
#define IDB_STOP_ALL                    5
#define IDB_ADVISE                      6
#define IDB_UNADVISE                    7
#define IDC_PICTURE                     8
#define IDP_OLE_INIT_FAILED             100
#define IDD_MDRIVE_DIALOG               102
#define IDR_MAINFRAME                   128

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
