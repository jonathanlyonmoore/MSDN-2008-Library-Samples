//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by circ.rc
//
#define IDS_CIRCCTL_DESC                1
#define IDR_CircCtl                     1
#define IDS_DOCSTRING                   2
#define IDS_TITLE                       3
#define IDS_HELPFILE                    4
#define IDD_CIRCPROPS                   201
#define IDC_COMBO1                      201
#define IDC_EDIT1                       203
#define IDC_APPLY                       204

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         209
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
