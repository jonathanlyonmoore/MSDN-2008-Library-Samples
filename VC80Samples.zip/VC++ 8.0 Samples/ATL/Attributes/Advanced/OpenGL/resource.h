//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OpenGL.rc
//
#define IDS_OPENGLOBJ_DESC              1
#define IDR_OpenGLObj                   1
#define IDI_ICON1                       202

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
