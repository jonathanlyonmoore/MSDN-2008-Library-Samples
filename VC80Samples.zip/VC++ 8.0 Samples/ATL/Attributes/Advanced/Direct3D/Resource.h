//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Direct3D.rc
//
#define IDB_TOOLBTN                     1
#define IDS_ERR_OUTOFMEMORY             5
#define IDS_ERR_EXCEPTION               6
#define IDS_ERR_GENERIC                 7
#define IDS_ERR_OUTOFVIDEOMEMORY        8
#define IDS_ERR_SURFACEBUSY             9
#define IDS_ERR_SURFACELOST             10
#define IDS_ERR_WRONGMODE               11
#define IDS_ERR_INTERNALERROR           12
#define IDS_PROJNAME                    100
#define IDS_PROJNAME2                   101
#define IDR_Direct3D                    201

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        204
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
