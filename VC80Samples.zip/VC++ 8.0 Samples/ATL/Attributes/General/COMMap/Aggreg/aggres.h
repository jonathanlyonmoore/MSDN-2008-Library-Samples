//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Aggreg.rc
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Classes Reference and related electronic
// documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft C++ Libraries products.

#define IDS_AGG_DESC    1
#define IDS_AGGBLIND_DESC   2
#define IDS_AUTOAGG_DESC    3
#define IDS_AUTOAGGB_DESC   4
#define IDS_SERVICENAME 100

#define IDR_Agg 1
#define IDR_AggBlind    2
#define IDR_AutoAgg 3
#define IDR_AutoAggB    4


// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
